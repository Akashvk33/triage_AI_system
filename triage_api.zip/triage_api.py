from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from typing import Optional
import joblib
import pandas as pd
import numpy as np
import shap

# ==================================================
# 🔐 SINGLE API KEY
# ==================================================

API_KEY = "ak_live_triage_9f4c8b72e1d64a7c95b3f0182ac7d9e4"

# ==================================================
# Load Trained Artifacts
# ==================================================

calibrated_model = joblib.load("semantic_lightgbm_risk_model.pkl")
base_model = joblib.load("semantic_lightgbm_base_model.pkl")
embedder = joblib.load("minilm_embedder.pkl")
encoders = joblib.load("feature_encoders.pkl")
target_encoder = joblib.load("target_encoder.pkl")

explainer = shap.TreeExplainer(base_model)

app = FastAPI(title="AI Smart Triage API")


# ==================================================
# Fully Nullable Input Schema
# ==================================================

class PatientInput(BaseModel):
    Patient_ID: Optional[str] = None
    Age: Optional[int] = None
    Gender: Optional[str] = None
    Symptoms: Optional[str] = None
    Heart_Rate: Optional[int] = None
    Temperature: Optional[float] = None
    Blood_Pressure: Optional[str] = None
    Pre_Existing_Conditions: Optional[str] = None
    Red_Flags: Optional[str] = None


# ==================================================
# Risk → Triage Tier Mapping
# ==================================================

def map_risk_to_tier(risk_label):
    if risk_label == "Critical":
        return "Immediate"
    elif risk_label == "High":
        return "Urgent"
    else:
        return "Standard"


# ==================================================
# 15 Department Routing
# ==================================================

def assign_department(symptoms, red_flags):

    text = (str(symptoms) + " " + str(red_flags)).lower()

    if any(x in text for x in ["severe bleeding", "major accident"]):
        return "Trauma & Emergency Surgery"
    if any(x in text for x in ["suicidal", "hallucination", "depression", "panic"]):
        return "Psychiatry"
    if any(x in text for x in ["chest pain", "palpitations", "heart"]):
        return "Cardiology"
    if any(x in text for x in ["confusion", "seizure", "stroke", "numbness"]):
        return "Neurology"
    if any(x in text for x in ["fracture", "bone", "joint"]):
        return "Orthopedics"
    if any(x in text for x in ["asthma", "shortness of breath", "lung"]):
        return "Pulmonology"
    if any(x in text for x in ["stomach", "vomiting", "diarrhea", "liver"]):
        return "Gastroenterology"
    if any(x in text for x in ["kidney", "renal", "urine"]):
        return "Nephrology"
    if any(x in text for x in ["diabetes", "thyroid", "hormonal"]):
        return "Endocrinology"
    if any(x in text for x in ["child", "infant"]):
        return "Pediatrics"
    if any(x in text for x in ["pregnancy", "labor", "ovarian"]):
        return "Obstetrics & Gynecology"
    if any(x in text for x in ["rash", "itchy", "skin"]):
        return "Dermatology"
    if any(x in text for x in ["ear", "sinus", "throat", "nose"]):
        return "ENT"
    if any(x in text for x in ["tumor", "cancer", "mass"]):
        return "Oncology"

    return "General Medicine"


# ==================================================
# Safe Preprocessing
# ==================================================

def preprocess_input(data_dict):

    df = pd.DataFrame([data_dict])

    if "Patient_ID" in df.columns:
        df = df.drop(columns=["Patient_ID"])

    df["Symptoms"] = df["Symptoms"].fillna("Unknown")
    df["Gender"] = df["Gender"].fillna("Unknown")
    df["Pre_Existing_Conditions"] = df["Pre_Existing_Conditions"].fillna("None")
    df["Red_Flags"] = df["Red_Flags"].fillna("None")

    df["Age"] = df["Age"].fillna(0)
    df["Heart_Rate"] = df["Heart_Rate"].fillna(0)
    df["Temperature"] = df["Temperature"].fillna(0)
    df["Blood_Pressure"] = df["Blood_Pressure"].fillna("0/0")

    embeddings = embedder.encode([df["Symptoms"].iloc[0]])
    embedding_df = pd.DataFrame(
        embeddings,
        columns=[f"symptom_emb_{i}" for i in range(embeddings.shape[1])]
    )

    df = df.drop(columns=["Symptoms"])
    df = pd.concat([df.reset_index(drop=True), embedding_df], axis=1)

    bp_split = df["Blood_Pressure"].astype(str).str.split("/", expand=True)
    df["BP_Systolic"] = pd.to_numeric(bp_split[0], errors="coerce").fillna(0)
    df["BP_Diastolic"] = pd.to_numeric(bp_split[1], errors="coerce").fillna(0)
    df.drop(columns=["Blood_Pressure"], inplace=True)

    for col, encoder in encoders.items():
        if col in df.columns:
            value = df[col].iloc[0]
            if value in encoder.classes_:
                df[col] = encoder.transform([value])
            else:
                df[col] = encoder.transform([encoder.classes_[0]])

    return df


# ==================================================
# SHAP JSON Explanation Generator
# ==================================================

def generate_shap_json(processed_df, predicted_class_index):

    shap_values = explainer.shap_values(processed_df)

    if isinstance(shap_values, list):
        shap_for_class = shap_values[predicted_class_index][0]
    else:
        shap_for_class = shap_values[0][:, predicted_class_index]

    feature_names = processed_df.columns.tolist()

    impacts = []
    for i, val in enumerate(shap_for_class):
        impacts.append({
            "feature": feature_names[i],
            "impact_score": float(val),
            "direction": "increase" if val > 0 else "decrease"
        })

    impacts = sorted(impacts, key=lambda x: abs(x["impact_score"]), reverse=True)

    return {
        "top_drivers": impacts[:5],
        "base_value": float(explainer.expected_value[predicted_class_index]
                            if isinstance(explainer.expected_value, (list, np.ndarray))
                            else explainer.expected_value)
    }


# ==================================================
# Protected Prediction Endpoint
# ==================================================

@app.post("/predict")
def predict(
    patient: PatientInput,
    x_api_key: str = Header(...)
):

    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized - Invalid API Key")

    try:
        data = patient.dict()
        patient_id = data.get("Patient_ID", None)

        processed = preprocess_input(data)

        probabilities = calibrated_model.predict_proba(processed)[0]
        predicted_class_index = int(np.argmax(probabilities))
        confidence_score = float(np.max(probabilities))

        predicted_risk = target_encoder.inverse_transform(
            [predicted_class_index]
        )[0]

        triage_tier = map_risk_to_tier(predicted_risk)
        department = assign_department(data.get("Symptoms"), data.get("Red_Flags"))

        shap_explanation = generate_shap_json(
            processed,
            predicted_class_index
        )

        return {
            "Patient_ID": patient_id,
            "Predicted_Risk": predicted_risk,
            "Confidence_Score": round(confidence_score, 3),
            "Triage_Tier": triage_tier,
            "Assigned_Department": department,
            "Explainability": shap_explanation
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/")
def health_check():
    return {"status": "AI Smart Triage API running (Structured SHAP JSON Mode)"}
